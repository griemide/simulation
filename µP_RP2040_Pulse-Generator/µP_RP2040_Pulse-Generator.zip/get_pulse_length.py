# 2023-04-23
# Michael Gries

# Um die Impulslänge an Pin 1 des RP2-Boards zu ermitteln,
# können wir den integrierten Interrupt-Handler des Boards nutzen

import machine
import utime

# Pin 1 konfigurieren
pin_gpio1 = machine.Pin(1, machine.Pin.IN, machine.Pin.PULL_UP)
start_time = utime.ticks_us() # since triggered on high level firsttime

# Interrupt-Handler definieren
def handle_interrupt(pin):
    global start_time, pulse_length
    if pin == pin_gpio1:
        if pin_gpio1.value():
            # Wenn der Pin high wird, speichern wir die Startzeit
            start_time = utime.ticks_us()
            print("Impuls detektiert ... ")
        else:
            # Wenn der Pin low wird, berechnen wir die Impulslänge
            pulse_length = utime.ticks_diff(utime.ticks_us(), start_time)
            print("Ermittelte Impulslänge an GPIO1: {} ms".format(pulse_length / 1000))

# Interrupt für Pin 1 konfigurieren
pin_gpio1.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=handle_interrupt)
# pin_gpio1.irq(trigger=machine.Pin.IRQ_LOW_LEVEL | machine.Pin.IRQ_HIGH_LEVEL, handler=handle_interrupt)
print("Detektierung der Impulslänge an GPIO1 (Pin2) aktiviert ...")

# Schleife, die die Impulslänge ausgibt
# while True:
#     print("Ermittelte Impulslänge an GPIO1: {} ms".format(pulse_length))
#     utime.sleep_ms(100)

import timer_random_pulse_length 
