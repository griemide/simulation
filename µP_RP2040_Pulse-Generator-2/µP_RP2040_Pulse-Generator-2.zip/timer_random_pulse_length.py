# 2023-04-23
# Michael Gries

# Dieses Skript konfiguriert Pin GPIO0 als Ausgang und
# definiert dann einen Timer-Handler timer_handler(),
# der aufgerufen wird, wenn der Timer abläuft.
# In der Handler-Funktion wird eine zufällige Impulslänge zwischen 1000ms und 3000ms generiert und
# der Pin auf high gesetzt.
#
# Ein One-Shot-Timer wird dann mit der Impulslänge konfiguriert,
# der nach Ablauf die Timer-Callback-Funktion timer_callback() aufruft, die den Pin auf low setzt.

# Das Skript konfiguriert auch einen wiederholten Timer,
# der alle 10 Sekunden den Timer-Handler timer_handler() aufruft,
# um eine neue zufällige Impulslänge zu generieren und den One-Shot-Timer zu starten.

import machine
import random
import utime

# Pins konfigurieren
pin_gpio0 = machine.Pin(0, machine.Pin.OUT) # entspricht dem Pin 1 des RP2-boards
pin_onboard_led = machine.Pin("LED", machine.Pin.OUT) # entspricht WL_GPIO es Infineon Chip

pin_gpio21 = machine.Pin(21, machine.Pin.OUT) # switch 2 status
pin_gpio27 = machine.Pin(27, machine.Pin.IN, machine.Pin.PULL_UP) # switch 2 mode
pin_gpio28 = machine.Pin(28, machine.Pin.IN, machine.Pin.PULL_UP) # Logic Analyser Trigger


# Intervall konfigurieren
intervall = 5000
#print("Intervall: {}ms".format(intervall))

# Timer-Handler definieren
def timer_handler(timer):
    global pulse_length

    # Zufällige Impulslänge zwischen 1000ms und 3000ms generieren
    pulse_length = random.randint(1000, 3000)
    if intervall == 0:
        timer_intervall.deinit() # Stoppe den Timer
        print("... Intervall-Timer wurde gestoppt.")
        
    print("Intervall: {} ms & generierte Pulslänge an GPIO0: {} ms".format(intervall, pulse_length))
    
    # Lese den Wert von GPIO 27 ein
    value = pin_gpio27.value()
    print("Pin 27: {}".format(value))
    # Spiegle den Wert und gib ihn auf GPIO 21 aus
    if value == 1:
        pin_gpio21.off()
    else:
        pin_gpio21.on()

    # Pin auf high setzen und Impulslänge warten
    pin_gpio0.on()
    pin_onboard_led.on()
    timer_pulse = machine.Timer(-1)
    timer_pulse.init(period=pulse_length, mode=machine.Timer.ONE_SHOT, callback=timer_callback)

# Timer-Callback definieren
def timer_callback(timer):
    # Pin auf low setzen
    pin_gpio0.off()
    pin_onboard_led.off()

# Timer konfigurieren
timer_intervall = machine.Timer(-1) # default für RP2 board
timer_intervall.init(period=intervall, mode=machine.Timer.PERIODIC, callback=timer_handler)

print("Generierte Pulslängen an GPIO0 (Pin1) und Onboard-LED zwischen 1000 ms und 3000 ms fix.")
print("Stoppen des Intervall-Timers mit Eingabe 'intervall=0'")
print("Intervall-Timer mit {} ms gestartet ...".format(intervall))

# Endlosschleife (deaktiviert, um Eingaben der Thonny IDE Shell zu ermöglichen)
# while True:
#     pass
